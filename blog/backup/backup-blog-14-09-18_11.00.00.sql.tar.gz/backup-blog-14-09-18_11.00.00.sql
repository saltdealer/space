-- MySQL dump 10.13  Distrib 5.5.37, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: blog
-- ------------------------------------------------------
-- Server version	5.5.37-0ubuntu0.13.10.1
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `name` varchar(50) NOT NULL,
  `summary` varchar(200) NOT NULL,
  `content` mediumtext NOT NULL,
  `category` bigint(20) NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` VALUES ('0014094870426421f86154590014bb7be5295046c28e588000','0010018336417540987fff4508f43fbaed718e263442526000','GoodOak','http://ww4.sinaimg.cn/mw690/679a7135jw1ejvsmtdv37j204q045wed.jpg','乐亭旅游','8月中旬和同事一起去了唐山的乐亭。登上了当地美丽的月坨岛。','<p>&nbsp;</p>\n<p>&nbsp; &nbsp; <span class=\"example1 example2\">来到百度移动安全快三个月了，这是第二次和同事出来玩了。乘船登上了当地的月坨岛。刚上码头就看到海边漂亮的别墅。</span></p>\n<p>&nbsp; &nbsp;&nbsp;<img src=\"http://ww1.sinaimg.cn/mw690/679a7135jw1ejw2pmtd8yj21kw0w0dvp.jpg\" alt=\"海边别墅\" width=\"690\" height=\"388\" /></p>\n<p>&nbsp; &nbsp; 有进去过里面，是实木盖的房子，一楼房间里靠窗放置着喝茶的座椅，感觉是很平淡，悠闲的生活调调。</p>\n<hr />\n<p>&nbsp;</p>\n<p>&nbsp; &nbsp; 上岛之后，有一片林子，穿过了林子可以看到岛上的湿地，不时有鸟群在湿地上空飞过。</p>\n<p>&nbsp; &nbsp;&nbsp;<img src=\"http://ww3.sinaimg.cn/mw690/679a7135jw1ejw0yqlkkvj21kw11x7me.jpg\" alt=\"湿地\" width=\"690\" height=\"460\" /></p>\n<hr />\n<p>&nbsp;</p>\n<p>&nbsp; &nbsp; 出了林子，最后就到了沙滩上。我一个人跑去逛了逛，发现海边的长桥上有一个瞭望台，这种海边的常见建筑以前还只是在电视上看到过，现在看着就有入戏的感觉了。</p>\n<p>&nbsp; &nbsp;&nbsp;<img src=\"http://ww1.sinaimg.cn/mw690/679a7135jw1ejw2pkfqnvj20w01kwwod.jpg\" alt=\"\" width=\"690\" height=\"1227\" /></p>\n<p>&nbsp;</p>\n<hr />\n<p>&nbsp;</p>\n<p>&nbsp; &nbsp;&nbsp;<img src=\"http://ww4.sinaimg.cn/mw690/679a7135jw1ejw2pj4utyj218e0oyjxg.jpg\" alt=\"\" width=\"690\" height=\"388\" /></p>\n<p>&nbsp; &nbsp; 周末的游玩，很快就结束了。对北方的生活还是不能适应，希望不久后生活能变得生动点。</p>\n<p>&nbsp;2014-09-02</p>',2,1409487042.64);

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `category_id` varchar(50) NOT NULL,
  `category` varchar(50) NOT NULL,
  PRIMARY KEY (`category_id`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

INSERT INTO `category` VALUES ('1','学习笔记');
INSERT INTO `category` VALUES ('2','生活记录');
INSERT INTO `category` VALUES ('3','其他');

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` varchar(50) NOT NULL,
  `blog_id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--


--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(500) NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES ('0010018336417540987fff4508f43fbaed718e263442526000','jjxx2004@gmail.com','30a756507840db3af6a8645c15c485e0',1,'GoodOak','http://ww4.sinaimg.cn/mw690/679a7135jw1ejvsmtdv37j204q045wed.jpg',1402909113.628);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-09-17 22:58:31
